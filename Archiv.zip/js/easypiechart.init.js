$(function() {
    $('#chart1').easyPieChart({
        barColor: '#ffc107',
        trackColor: '#f0f1f3',
        //your configuration goes here
    });  
    $('#chart2').easyPieChart({
        barColor: '#377dff',
		trackColor: '#f0f1f3',
        //your configuration goes here
    }); 
    $('#chart3').easyPieChart({
        barColor: '#de4437',
		trackColor: '#f0f1f3',
        //your configuration goes here
    }); 
    $('#chart4').easyPieChart({
        barColor: '#00c9a7',
		trackColor: '#f0f1f3',
        //your configuration goes here
    }); 
}); 